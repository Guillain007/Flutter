

class Personnel 

{
  int matricule =0;
  String name ='';
  String surname = '';
  int age =0;

  //==========================================================
  //============== le mutateur ======================
  void setmatricule(int matricule )
  {
    this.matricule = matricule;
  }
  void setname (String name)
  {
    this.name = name;
  }
  void setsurname (String surname)
  {
    this.surname = surname;
  }
  void setage (int age)
  {
    this.age = age;
  }

  //==========================================================
  //============== les Accesseurs ======================

  int getmatricule(){
    return this.matricule;
  }
  String getname(){
    return this.name;
  }
  String getsurname(){
    return this.surname;
  }
  int getage(){
    return this.age;
  }

}
class Etudiant 

{
   int id =0;
   String nom ='';
   String postnom ='';
   String prenom ='';
   String sexe ='';
   int ages = 0;
   String date = '';
   double poids =0;
   double taille = 0;

//=======================================================

   void setid (int id )
  {
    this.id = id;
  }
  void setnom (String nom)
  {
    this.nom = nom;
  }
  void setpostnom (String postnom)
  {
    this.postnom = postnom;
  }
  void setprenom (String prenom)
  {
    this.prenom = prenom;
  }
  void setsexe (String sexe)
  {
    this.sexe = sexe;
  }
   void setages (int ages)
  {
    this.ages = ages;
  }
  void setdate (String date)
  {
    this.date = date;
  }
  void setpoids (double poids)
  {
    this.poids = poids;
  }
  void settaille (double taille)
  {
    this.taille = taille;
  }

//=======================================================

  int getid(){
    return this.id;
  }
  String getnom(){
    return this.nom;
  }
  String getpostnom(){
    return this.postnom;
  }
  String getprenom(){
    return this.prenom;
  }
  String getsexe(){
    return this.sexe;
  }
  int getage(){
    return this.ages;
  }
  String getdate(){
    return this.date;
  }
  double getpoids(){
    return this.poids;
  }
  double gettaille(){
    return this.taille;
  }

}