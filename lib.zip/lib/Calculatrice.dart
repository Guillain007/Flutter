import 'package:flutter/material.dart';

class Calc extends StatefulWidget {
  const Calc({ Key? key }) : super(key: key);

  @override
  State<Calc> createState() => _CalcState();
}

class _CalcState extends State<Calc> {

  TextEditingController txtNombre1 = new TextEditingController();
  TextEditingController txtNombre2 = new TextEditingController();
  TextEditingController txtReponse = new TextEditingController();

  void Addition()
  {
    int x = int.parse(txtNombre1.text);
    int y = int.parse(txtNombre2.text);

    int rep =x+y;

    txtReponse.text= rep.toString();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("ADDITION"),
        backgroundColor: Colors.blue,
      ),
      body: ListView(
        children: [
          new TextField(
            controller: txtNombre1,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              hintText: "Entrez le nombre",
              labelText: "Entrez le nombre"
            ),
          ),
          new TextField(
            controller: txtNombre2,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
            hintText: "Entrez le nombre",
            labelText: "Entrez le nombre"
            ),
          ),

          RaisedButton(onPressed:(){},
          child: Text("Addition"),
          color: Colors.blue,
          )
          
        ],
      ),
    );
  }
}